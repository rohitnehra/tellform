'use strict';

// Use Application configuration module to register a new module
ApplicationConfiguration.registerModule('users');
#!/bin/bash

node server.js
#pm2 start process.yml
